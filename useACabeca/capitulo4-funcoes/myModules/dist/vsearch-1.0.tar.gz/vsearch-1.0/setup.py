from setuptools import setup

setup(
    name='vsearch'
    ,version='1.0'
    ,description='Ferramenta de pesquisa de letras'
    ,author='HF Python 2e'
    ,author_email=''
    ,url=''
    ,py_modules=['vsearch'],
)
